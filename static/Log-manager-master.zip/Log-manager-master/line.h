// Project Identiifer: 01BD41C3BF016AD7E8B6F837DF18926EC3E83350
#pragma once
#include <string>
#include <string.h>
#include <vector>

using namespace std;

struct Line {
    Line() {}

    Line(long long int t_in, string cat_in, string cat_lower_in, string msg_in, string time_str_in, int entry_in)
        : time_int(t_in), cat(cat_in), cat_lower(cat_lower_in), msg(msg_in), time_str(time_str_in), entry_num(entry_in) {}

    long long int time_int = 0;
    string cat = "";
    string cat_lower = "";
    string msg = "";
    string time_str = "";
    int entry_num = 0;
};

struct UpperComp {
    bool operator()(const long long int lhs, const Line& rhs) const {
        return lhs < rhs.time_int;
    }
};

struct LowerComp {
    bool operator()(const Line& lhs, const long long int rhs) const {
        return lhs.time_int < rhs;
    }
};

struct LineComp {
    bool operator()(const Line& lhs, const Line& rhs) const {
        if (lhs.time_int != rhs.time_int) {
            return lhs.time_int < rhs.time_int;
        }
        if (lhs.cat_lower != rhs.cat_lower) {
            return lhs.cat_lower < rhs.cat_lower;
        }
        return lhs.entry_num < rhs.entry_num;
    }
};