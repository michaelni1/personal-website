// Project Identiifer: 01BD41C3BF016AD7E8B6F837DF18926EC3E83350

#include <string>
#include <iostream>
#include <fstream>
#include "line.h"
#include "log.h"

using namespace std;

// Print help for the user when requested.
// argv[0] is the name of the currently executing program
void printHelp() {
    cout << "usage: ./logman [logfile] [redirection]\n";
} // printHelp()

int main(int argc, char* argv[]) {
    std::ios_base::sync_with_stdio(false);
    if (argc == 0) {
        exit(1);
    }
    string infile(argv[1]);
    if (infile == "-h" || infile == "--help") {
        printHelp();
        exit(1);
    }

    ifstream login(infile);

    Log result;
    result.read_log(login);
    result.read_cmds();
    return 0;
}