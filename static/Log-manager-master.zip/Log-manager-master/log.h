// Project Identiifer: 01BD41C3BF016AD7E8B6F837DF18926EC3E83350
#pragma once
#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <stdio.h>
#include <utility>
#include <algorithm>
#include <deque>
#include <unordered_map>
#include <string.h>
#include <cassert>
#include <set>
#include <iterator>
#include "line.h"

using namespace std;

class Log {
public:
    long long int ts_to_ti(string time_str) {
        time_str.erase(remove(time_str.begin(), time_str.end(), ':'), time_str.end());
        return stoll(time_str);
    }
    void read_log(istream& fin);

    void read_cmds();

    void timestamps_search(string time_in);

    void matching_search(string time_in);

    void append_log(int pos);

    void append_search();

    void category_search(string cat_in);

    void keyword_search(string key_in);

    void print_excerpt();

    void print_search();

    void delete_log(int pos);

    void move_begin(int pos);

    void move_end(int pos);

    void sort_excerpt();

    void clear_excerpt();

private:
    unordered_map<string, vector<unsigned int>> cat_map;
    unordered_map<string, vector<unsigned int>> key_map;
    vector<unsigned int> unsorted_master;
    //unsigned int in sorted master references unsorted master
    vector<Line> sorted_master;
    //unsigned int references sorted_master
    deque<unsigned int> excerpt;
    vector<unsigned int> latest_search;
    bool searched = false;
};

struct SetComp {
    SetComp(vector<Line>& master)
        : sorted_master(&master) {}

    vector<Line>* sorted_master;

    bool operator()(const unsigned int lhs, const unsigned int rhs) const {
        if ((*sorted_master)[lhs].time_int < (*sorted_master)[rhs].time_int) {
            return true;
        }
        if ((*sorted_master)[lhs].time_int == (*sorted_master)[rhs].time_int) {
            if ((*sorted_master)[lhs].cat_lower < (*sorted_master)[rhs].cat_lower) {
                return true;
            }
            if ((*sorted_master)[lhs].cat_lower == (*sorted_master)[rhs].cat_lower) {
                return (*sorted_master)[lhs].entry_num < (*sorted_master)[rhs].entry_num;
            }
            return false;
        }
        return false;
    }
};