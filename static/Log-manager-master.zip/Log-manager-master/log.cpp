// Project Identiifer: 01BD41C3BF016AD7E8B6F837DF18926EC3E83350
#include "log.h"

bool isalnum_pred(char in) {
    return isalnum(in) != 0;
}
//use insert for unordered map
void Log::read_log(istream& fin) {
    string time_str = "";
    string cat = "";
    string msg = "";
    int entry_num = 0;
    //read log file
    while (getline(fin, time_str, '|')) {
        long long int time_int = ts_to_ti(time_str);
        getline(fin, cat, '|');
        getline(fin, msg);
        //create line and push into master log
        string cat_lower(cat);
        transform(cat.begin(), cat.end(), cat_lower.begin(), ::tolower);
        Line line_in(time_int, cat, cat_lower, msg, time_str, entry_num);
        sorted_master.push_back(line_in);
        ++entry_num;
    }
    cout << entry_num << " entries read\n";

    //sort log entries
    sort(sorted_master.begin(), sorted_master.end(), LineComp());
    unsorted_master.resize(sorted_master.size());
    unsigned int index_sorted = 0;
    for (auto it = sorted_master.begin(); it != sorted_master.end(); ++it) {
        unsorted_master[it->entry_num] = index_sorted;
        //input the index of sorted line that indexes into unsorted_master into cat_map
        auto cat_it = cat_map.find(it->cat_lower);
        if (cat_it == cat_map.end()) {
            cat_map.insert(pair<string, 
                vector<unsigned int>>(it->cat_lower, vector<unsigned int>(1, index_sorted)));
        }
        else {
            cat_it->second.push_back(index_sorted);
        }
        string msg_copy(it->msg);
        //build keyword map, first append cat string to msg string
        msg_copy += "*" + it->cat_lower;
        //find first occurrence of alphanum
        auto msg_range1 = find_if(msg_copy.begin(), msg_copy.end(), isalnum_pred);
        while (msg_range1 != msg_copy.end()) {
            //find second occurrence of alphanum
            auto msg_range2 = find_if_not(msg_range1 + 1, msg_copy.end(), isalnum_pred);
            string key_msg(msg_range1, msg_range2);
            transform(key_msg.begin(), key_msg.end(), key_msg.begin(), ::tolower);
            //insert key_msg with lowercase and alphanum chars
            auto key_it = key_map.find(key_msg);
            if (key_it == key_map.end()) {
                key_map.insert(pair<string, vector<unsigned int>>(key_msg, vector<unsigned int>(1, index_sorted)));
            }
            else if (key_it->second.back() != index_sorted) {
                key_it->second.push_back(index_sorted);
            }
            //repeat until end of msg
            msg_range1 = find_if(msg_range2, msg_copy.end(), isalnum_pred);
        }
        ++index_sorted;
    }
}

void Log::timestamps_search(string time_in) {
    latest_search.clear();
    size_t first_bar = time_in.find('|');
    string first = time_in.substr(0, first_bar);
    string last = time_in.substr(first_bar + 1, string::npos);
    if (first.size() != 14 || last.size() != 14) {
        return;
    }
    long long int time_first = ts_to_ti(first);
    long long int time_last = ts_to_ti(last);
    //return if time_first is greater than greatest time or time_last is less than least time
    if (time_first > (*sorted_master.rbegin()).time_int || 
        time_last < (*sorted_master.begin()).time_int) {
        cout << "Timestamps search: 0 entries found\n";
        return;
    }
    //find lower bound and upper bound
    auto it_low = lower_bound(sorted_master.begin(), sorted_master.end(), time_first, LowerComp());
    auto it_upp = upper_bound(it_low, sorted_master.end(), time_last, UpperComp());
    //push_back range
    for (auto it = it_low; it != it_upp; ++it) {
        latest_search.push_back((unsigned int)(it - sorted_master.begin()));
    }
    cout << "Timestamps search: " << latest_search.size() << " entries found\n";
}

void Log::matching_search(string time_in) {
    latest_search.clear();
    long long int time = ts_to_ti(time_in);
    //check for range
    auto it_low = lower_bound(sorted_master.begin(), sorted_master.end(), time, LowerComp());
    if (it_low == sorted_master.end()) {
        cout << "Timestamp search: 0 entries found\n";
        return;
    }
    auto it_upp = upper_bound(it_low, sorted_master.end(), time, UpperComp());
    //push_back range between bounds
    for (auto it = it_low; it != it_upp; ++it) {
        latest_search.push_back((unsigned int)(it - sorted_master.begin()));
    }
    cout << "Timestamp search: " << latest_search.size() << " entries found\n";
}

void Log::append_log(int pos) {
    if ((size_t)pos >= unsorted_master.size() || pos < 0) {
        return;
    }
    excerpt.push_back(unsorted_master[pos]);
    cout << "log entry " << pos << " appended\n";
}

void Log::category_search(string cat_in) {
    latest_search.clear();
    transform(cat_in.begin(), cat_in.end(), cat_in.begin(), ::tolower);
    //find category in unordered_map cat_map
    auto it = cat_map.find(cat_in);
    if (it == cat_map.end()) {
        cout << "Category search: 0 entries found\n";
        return;
    }
    //push_back vector associated with key
    for (auto vec_it = it->second.begin(); vec_it != it->second.end(); ++vec_it) {
        latest_search.push_back(*vec_it);
    }
    cout << "Category search: " << latest_search.size() << " entries found\n";
}

void Log::print_excerpt() {
    int pos = 0;
    for (auto it = excerpt.begin(); it != excerpt.end(); ++it) {
        cout << pos << "|" << sorted_master[*it].entry_num << "|" << sorted_master[*it].time_str
            << "|" << sorted_master[*it].cat << "|" << sorted_master[*it].msg << "\n";
        ++pos;
    }
}

void Log::print_search() {
    for (auto it = latest_search.begin(); it != latest_search.end(); ++it) {
        cout << sorted_master[*it].entry_num << "|" << sorted_master[*it].time_str
            << "|" << sorted_master[*it].cat << "|" << sorted_master[*it].msg << "\n";
    }
}

void Log::append_search() {
    if (!searched) {
        return;
    }
    for (auto it = latest_search.begin(); it != latest_search.end(); ++it) {
        excerpt.push_back(*it);
    }
    cout << latest_search.size() << " log entries appended\n";
}

void Log::delete_log(int pos) {
    if ((size_t)pos >= excerpt.size() || pos < 0) {
        return;
    }
    excerpt.erase(excerpt.begin() + pos);
    cout << "Deleted excerpt list entry " << pos << "\n";
}

void Log::move_begin(int pos) {
    if ((size_t)pos >= excerpt.size() || pos < 0) {
        return;
    }
    excerpt.push_front(*(excerpt.begin() + pos));
    excerpt.erase(excerpt.begin() + pos + 1);
    cout << "Moved excerpt list entry " << pos << "\n";
}

void Log::move_end(int pos) {
    if ((size_t)pos >= excerpt.size() || pos < 0) {
        return;
    }
    excerpt.push_back(*(excerpt.begin() + pos));
    excerpt.erase(excerpt.begin() + pos);
    cout << "Moved excerpt list entry " << pos << "\n";
}

void Log::sort_excerpt() {
    if (excerpt.empty()) {
        cout << "excerpt list sorted\n(previously empty)\n";
        return;
    }

    cout << "excerpt list sorted\nprevious ordering:\n";
    cout << "0|" << sorted_master[excerpt.front()].entry_num << "|" << sorted_master[excerpt.front()].time_str << "|"
        << sorted_master[excerpt.front()].cat << "|" << sorted_master[excerpt.front()].msg << "\n" << "...\n";

    cout << excerpt.size() - 1 << "|" << sorted_master[excerpt.back()].entry_num << "|" 
        << sorted_master[excerpt.back()].time_str << "|" << sorted_master[excerpt.back()].cat 
        << "|" << sorted_master[excerpt.back()].msg << "\n";

    sort(excerpt.begin(), excerpt.end());
    cout << "new ordering:\n";
    cout << "0|" << sorted_master[excerpt.front()].entry_num << "|" << sorted_master[excerpt.front()].time_str << "|"
        << sorted_master[excerpt.front()].cat << "|" << sorted_master[excerpt.front()].msg << "\n" << "...\n";

    cout << excerpt.size() - 1 << "|" << sorted_master[excerpt.back()].entry_num << "|" 
        << sorted_master[excerpt.back()].time_str << "|" << sorted_master[excerpt.back()].cat 
        << "|" << sorted_master[excerpt.back()].msg << "\n";
}

void Log::clear_excerpt() {
    if (excerpt.empty()) {
        cout << "excerpt list cleared\n(previously empty)\n";
        return;
    }
    cout << "excerpt list cleared\nprevious contents:\n";
    cout << "0|" << sorted_master[excerpt.front()].entry_num << "|" << sorted_master[excerpt.front()].time_str << "|"
        << sorted_master[excerpt.front()].cat << "|" << sorted_master[excerpt.front()].msg << "\n" << "...\n";

    cout << excerpt.size() - 1 << "|" << sorted_master[excerpt.back()].entry_num << "|" 
        << sorted_master[excerpt.back()].time_str << "|" << sorted_master[excerpt.back()].cat 
        << "|" << sorted_master[excerpt.back()].msg << "\n";
    excerpt.clear();
}

void Log::keyword_search(string key_in) {
    latest_search.clear();
    vector<string> keywords;
    //convert keyword string into lowercase alphanum string
    auto key_range1 = find_if(key_in.begin(), key_in.end(), isalnum_pred);
    while (key_range1 != key_in.end()) {
        auto key_range2 = find_if_not(key_range1 + 1, key_in.end(), isalnum_pred);
        //construct string from two ranges and make lowercase
        string in(key_range1, key_range2);
        transform(in.begin(), in.end(), in.begin(), ::tolower);
        keywords.push_back(in);
        //repeat until end of keyword string
        key_range1 = find_if(key_range2, key_in.end(), isalnum_pred);
    }
    //first find the key-value pair with the first keyword
    auto start = key_map.find(keywords[0]);
    if (start == key_map.end()) {
        cout << "Keyword search: 0 entries found\n";
        return;
    }
    //set latest_search to vector of keyword's key in map
    latest_search.reserve(start->second.size());
    copy(start->second.begin(), start->second.end(), back_inserter(latest_search));
    if (keywords.size() == 1) {
        cout << "Keyword search: " << latest_search.size() << " entries found\n";
        return;
    }
    auto set_it = latest_search.end();
    for (size_t i = 1; i < keywords.size(); ++i) {
        //find next key-value pair
        auto it = key_map.find(keywords[i]);
        if (it == key_map.end()) {
            //exit if next iterator does not exist
            cout << "Keyword search: 0 entries found\n";
            latest_search.clear();
            return;
        }
        //perform set intersection with latest_search, back insert into result
        set_it = set_intersection(latest_search.begin(), set_it, it->second.begin(), it->second.end(),
            latest_search.begin(), SetComp(sorted_master));
    }
    latest_search.resize(set_it - latest_search.begin());
    cout << "Keyword search: " << latest_search.size() << " entries found\n";
}

void Log::read_cmds() {
    char cmd;
    do {
        cout << "% ";
        cin >> cmd;

        if (cmd == 't') {
            searched = true;
            string timestamp;
            cin >> timestamp;
            timestamps_search(timestamp);
        }
        else if (cmd == 'm') {
            searched = true;
            string timestamp;
            cin >> timestamp;
            matching_search(timestamp);
        }
        else if (cmd == 'a') {
            int pos;
            cin >> pos;
            append_log(pos);
        }
        else if (cmd == 'c') {
            searched = true;
            string category;
            cin >> ws;
            getline(cin, category);
            category_search(category);
        }
        else if (cmd == 'p') {
            print_excerpt();
        }
        else if (cmd == 'g') {
            print_search();
        }
        else if (cmd == 'r') {
            append_search();
        }
        else if (cmd == 'd') {
            int pos_in;
            cin >> pos_in;
            delete_log(pos_in);
        }
        else if (cmd == 'b') {
            int pos_in;
            cin >> pos_in;
            move_begin(pos_in);
        }
        else if (cmd == 'e') {
            int pos_in;
            cin >> pos_in;
            move_end(pos_in);
        }
        else if (cmd == 's') {
            sort_excerpt();
        }
        else if (cmd == 'l') {
            clear_excerpt();
        }
        else if (cmd == 'k') {
            searched = true;
            string keyword;
            getline(cin, keyword);
            keyword_search(keyword);
        }
        else {
            string comment;
            getline(cin, comment);
        }

    } while (cmd != 'q');
}