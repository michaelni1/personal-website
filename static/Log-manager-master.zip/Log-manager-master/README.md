# Log-manager

A log manager with utility functions.
<br /><br />
$ make
<br /><br />
Please structure your input file like in one of the test cases.
<br /><br />
$ ./logman [log file] [redirection to output file]
<br /><br />
Functions are as follows:<br /><br />
Timestamps range search:<br />
t [timestamp]|[timestamp]<br /><br />
Exact timestamp search:<br />
m [timestamp]<br /><br />
Append to output:<br />
a [integer position of search result]<br /><br />
Category search:<br />
c [category]<br /><br />
Print excerpt so far:<br />
p<br /><br />
Print search:<br />
g<br /><br />
Append search to excerpt list:<br />
r<br /><br />
Delete log:<br />
d [integer position]<br /><br />
Move log to beginning of excerpt:<br />
b [integer position]<br /><br />
Move log to end of excerpt:<br />
e [integer position]<br /><br />
Sort excerpt:<br />
s<br /><br />
Clear excerpt:<br />
l<br /><br />
Keyword search:<br />
k [keyword] <br /><br />
