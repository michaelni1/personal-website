// PROJECT IDENTIFIER: 40FB54C86566B9DDEAB902CC80E8CE85C1C62AAD
#include "hunt.h"
#include "coordinate.h"
#include <algorithm>

using namespace std;

void Hunt::captain_sq_hunt(string &c_sq, string &f_sq, string &hunt_order) {
    deque<Coordinate> sail_loc;
    map[start_loc.row][start_loc.col].dir = '@';
    sail_loc.push_back(start_loc);
    while (!sail_loc.empty()) {
        if (c_sq == "stack") {
            cur_sail_loc = sail_loc.back();
            sail_loc.pop_back();
            ++num_w_invest;
        }
        else {
            cur_sail_loc = sail_loc.front();
            sail_loc.pop_front();
            ++num_w_invest;
        }
        for (int i = 0; i < 4; ++i) {
            if (hunt_order[i] == 'n') {
                if (cur_sail_loc.row - 1 >= 0) {
                    captain_hunt(-1, 0, 'n', map[(size_t)cur_sail_loc.row - 1][cur_sail_loc.col], f_sq, hunt_order, sail_loc);
                    if (found_treas) {
                        break;
                    }
                }
                continue;
            }
            if (hunt_order[i] == 'e') {
                if (cur_sail_loc.col + 1 <= map_size - 1) {
                    captain_hunt(0, 1, 'e', map[cur_sail_loc.row][(size_t)cur_sail_loc.col + 1], f_sq, hunt_order, sail_loc);
                    if (found_treas) {
                        break;
                    }
                }
                continue;
            }
            if (hunt_order[i] == 's') {
                if (cur_sail_loc.row + 1 <= map_size - 1) {
                    captain_hunt(1, 0, 's', map[(size_t)cur_sail_loc.row + 1][cur_sail_loc.col], f_sq, hunt_order, sail_loc);
                    if (found_treas) {
                        break;
                    }
                }
                continue;
            }
            if (hunt_order[i] == 'w') {
                if (cur_sail_loc.col - 1 >= 0) {
                    captain_hunt(0, -1, 'w', map[cur_sail_loc.row][(size_t)cur_sail_loc.col - 1], f_sq, hunt_order, sail_loc);
                    if (found_treas) {
                        break;
                    }
                }
                continue;
            }
        }
        if (found_treas) {
            break;
        }
    }
}

void Hunt::fmate_sq_hunt(string &f_sq, string &hunt_order, Coordinate &start_in, char dir) {
    deque<Coordinate> land_loc;
    map[start_in.row][start_in.col].dir = dir;
    if (verbose) {
        string in = move("Went ashore at: " +
            to_string(start_in.row) + "," + to_string(start_in.col));
        ashore_out += move(in);
    }
    land_loc.push_back(start_in);
    while (!land_loc.empty()) {
        if (f_sq == "stack") {
            cur_land_loc = land_loc.back();
            land_loc.pop_back();
            ++num_l_invest;
        }
        else {
            cur_land_loc = land_loc.front();
            land_loc.pop_front();
            ++num_l_invest;
        }
        for (int i = 0; i < 4; ++i) {
            if (hunt_order[i] == 'n') {
                if (cur_land_loc.row - 1 >= 0) {
                    if (fmate_hunt(-1, 0, 'n', map[(size_t)cur_land_loc.row - 1][cur_land_loc.col], land_loc)) {
                        break;
                    }
                }
                continue;
            }
            if (hunt_order[i] == 'e') {
                if (cur_land_loc.col + 1 <= map_size - 1) {
                    if (fmate_hunt(0, 1, 'e', map[cur_land_loc.row][(size_t)cur_land_loc.col + 1], land_loc)) {
                        break;
                    }
                }
                continue;
            }
            if (hunt_order[i] == 's') {
                if (cur_land_loc.row + 1 <= map_size - 1) {
                    if (fmate_hunt(1, 0, 's', map[(size_t)cur_land_loc.row + 1][cur_land_loc.col], land_loc)) {
                        break;
                    }
                }
                continue;
            }
            if (hunt_order[i] == 'w') {
                if (cur_land_loc.col - 1 >= 0) {
                    if (fmate_hunt(0, -1, 'w', map[cur_land_loc.row][(size_t)cur_land_loc.col - 1], land_loc)) {
                        break;
                    }
                }
                continue;
            }
        }
        if (found_treas) {
            break;
        }
    }
    if (!found_treas && verbose) {
        ashore_out += "\nSearching island... party returned with no treasure.\n";
    }
}

void Hunt::captain_hunt(int row_add, int col_add, char dir_in, Tile &in, string &f_sq, string &hunt_order, 
    deque<Coordinate> &sail) {
    if (in.dir != '!' || in.terrain == '#') {
        return;
    }
    Coordinate new_loc(cur_sail_loc.row + row_add, cur_sail_loc.col + col_add);
    if (in.terrain == 'o') {
        ++num_ashore;
        start_land_treas = new_loc;
        fmate_sq_hunt(f_sq, hunt_order, new_loc, dir_in);
        return;
    }
    if (in.terrain == '.') {
        sail.push_back(new_loc);
        map[new_loc.row][new_loc.col].dir = dir_in;
        return;
    }
    if (in.terrain == '$') {
        map[new_loc.row][new_loc.col].dir = dir_in;
        if (verbose) {
            string in = move("Went ashore at: " +
                to_string(cur_sail_loc.row + row_add) + "," + to_string(cur_sail_loc.col + col_add));
            ashore_out += move(in);
        }
        ++num_l_invest;
        ++num_ashore;
        start_land_treas = new_loc;
        found_treas = true;
        return;
    }
}

bool Hunt::fmate_hunt(int row_add, int col_add, char dir, Tile &in, deque<Coordinate> &land) {
    if (in.dir != '!' || (in.terrain != '$' && in.terrain != 'o')) {
        return false;
    }
    Coordinate new_loc(cur_land_loc.row + row_add, cur_land_loc.col + col_add);
    if (in.terrain == 'o') {
        land.push_back(new_loc);
        map[new_loc.row][new_loc.col].dir = dir;
        return false;
    }
    else if (in.terrain == '$') {
        ++num_l_invest;
        map[new_loc.row][new_loc.col].dir = dir;
        found_treas = true;
        return true;
    }
    return false;
}

void Hunt::get_path() {
    Coordinate cur_loc(treas_loc.row, treas_loc.col);
    while (!(cur_loc == start_loc)) {
        char dir = map[cur_loc.row][cur_loc.col].dir;
        path_vec.push_back(cur_loc);
        if (dir == 'n') {
            cur_loc.row += 1;
        }
        else if (dir == 's') {
            cur_loc.row -= 1;
        }
        else if (dir == 'e') {
            cur_loc.col -= 1;
        }
        else {
            cur_loc.col += 1;
        }
    }
    path_vec.push_back(start_loc);
}

void Hunt::read_map() {
    if (map_type == "M") {
        char terrain;
        for (int i = 0; i < map_size; ++i) {
            for (int j = 0; j < map_size; ++j) {
                cin >> terrain;
                Tile in(terrain);
                map[i][j] = in;
                if (terrain == '$') {
                    treas_loc.row = i;
                    treas_loc.col = j;
                }
                if (terrain == '@') {
                    start_loc.row = i;
                    start_loc.col = j;
                }
            }
        }
    }
    else {
        int row;
        int col;
        char terrain;
        while (cin >> row) {
            cin >> col;
            cin >> terrain;
            Tile in(terrain);
            map[row][col] = in;
            if (terrain == '@') {
                start_loc.row = row;
                start_loc.col = col;
            }
            if (terrain == '$') {
                treas_loc.row = row;
                treas_loc.col = col;
            }
        }
    }
}

void Hunt::print_verbose() {
    cout << "Treasure hunt started at: " << start_loc.row << ","
        << start_loc.col << "\n";
    if (!found_treas) {
        cout << ashore_out;
        cout << "Treasure hunt failed\n";
    }
    else {
        cout << ashore_out;
        cout << "\nSearching island... party found treasure at "
            << treas_loc.row << "," << treas_loc.col << ".\n";
    }
}

void Hunt::print_treas_result() {
    if (!found_treas) {
        cout << "No treasure found after investigating " << num_w_invest + num_l_invest
            << " locations.";
    }
    else {
        cout << "Treasure found at " << treas_loc.row << "," << treas_loc.col
            << " with path length " << path_length() << ".";
    }
}

void Hunt::print_map_list() {
    cout << "Sail:\n";
    size_t sail = path_vec.size() - 1;
    while (!(path_vec[sail] == start_land_treas)) {
        cout << path_vec[sail].row << "," << path_vec[sail].col << "\n";
        --sail;
    }
    cout << "Search:\n";
    int land = (int)sail;
    while (land >= 0) {
        cout << path_vec[land].row << "," << path_vec[land].col << "\n";
        --land;
    }
}

void Hunt::print_map() {
    for (size_t i = 1; i < path_vec.size() - 1; ++i) {
        if (path_vec[i - 1].row == path_vec[i + 1].row) {
            map[path_vec[i].row][path_vec[i].col].terrain = '-';
        }
        else if (path_vec[i - 1].col == path_vec[i + 1].col) {
            map[path_vec[i].row][path_vec[i].col].terrain = '|';
        }
        else {
            map[path_vec[i].row][path_vec[i].col].terrain = '+';
        }
    }
    map[path_vec[0].row][path_vec[0].col].terrain = 'X';
    for (size_t i = 0; i < (size_t)map_size; ++i) {
        for (size_t j = 0; j < (size_t)map_size; ++j) {
            cout << map[i][j].terrain;
        }
        cout << "\n";
    }
}