// PROJECT IDENTIFIER: 40FB54C86566B9DDEAB902CC80E8CE85C1C62AAD
#ifndef HUNT_H
#define HUNT_H
#include <vector>
#include <deque>
#include <string>
#include <iostream>
#include <sstream>
#include <limits>
#include <cstddef>
#include <iterator>
#include "coordinate.h"

using namespace std;

class Hunt {
public:
    Hunt(int size_in, string map_type_in, bool verb_in) 
        : map_size(size_in), map_type(map_type_in), verbose(verb_in) {
        map.resize(map_size, vector<Tile>(map_size));
    }

    int get_water_invest() {
        return num_w_invest;
    }

    int get_land_invest() {
        return num_l_invest;
    }

    int get_num_ashore() {
        return num_ashore;
    }

    bool treas_found() {
        return found_treas;
    }

    int path_length() {
        return (int)(path_vec.size() - 1);
    }

    Coordinate get_treas_loc() {
        return treas_loc;
    }

    Coordinate get_start_loc() {
        return start_loc;
    }

    void read_map();

    void print_verbose();

    void print_treas_result();

    void print_map_list();

    void print_map();

    void captain_sq_hunt(string &c_sq, string &f_sq, string &hunt_order);

    void fmate_sq_hunt(string& f_sq, string& hunt_order, Coordinate& start_in, char dir);

    void captain_hunt(int row_add, int col_add, char dir_in, Tile &in, string &f_sq, 
        string &hunt_order, deque<Coordinate> &sail);

    //returns true if found treasure, false otherwise
    bool fmate_hunt(int row_add, int col_add, char dir, Tile &in, deque<Coordinate> &land);

    void get_path();

private:
    vector<Coordinate> path_vec;
    Coordinate cur_sail_loc;
    Coordinate cur_land_loc;
    Coordinate start_land_treas;
    Coordinate treas_loc;
    Coordinate start_loc;
    vector<vector<Tile>> map;
    string ashore_out;
    int map_size;
    string map_type;
    int num_w_invest = 0;
    int num_l_invest = 0;
    int num_ashore = 0;
    bool found_treas = false;
    bool verbose = false;
};

#endif