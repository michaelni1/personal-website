// PROJECT IDENTIFIER: 40FB54C86566B9DDEAB902CC80E8CE85C1C62AAD

#include <getopt.h>
#include <string>
#include <iostream>
#include <algorithm>
#include <sstream>
#include "hunt.h"

using namespace std;

struct cmdline {
    string hunt_order = "nesw";
    string show_path = "";
    string c_sq = "stack";
    string f_sq = "queue";
    bool verb = false;
    bool stats = false;
};

// Print help for the user when requested.
// argv[0] is the name of the currently executing program
void printHelp() {
    cout << "usage: ./hunt [options] [inputfile]\n";
} // printHelp()

// Process the command line; the only thing we need to return is the mode
// when the user specifies the -m/--mode option.
// return struct?
cmdline getCmd(int argc, char* argv[]) {
    string mode;
    cmdline cmds;

    // These are used with getopt_long()
    int choice;
    int option_index = 0;
    option long_options[] = {
        // TODO: Fill in two lines, for the "mode" ('m') and
        // the "help" ('h') options.
        { "captain", required_argument, nullptr, 'c' },
        { "first-mate", required_argument, nullptr, 'f' },
        { "hunt-order", required_argument, nullptr, 'o' },
        { "verbose", no_argument, nullptr, 'v' },
        { "stats", no_argument, nullptr, 's' },
        { "show-path", required_argument, nullptr, 'p' },
        { "help", no_argument,       nullptr, 'h' },
        { nullptr, 0,                nullptr, '\0' }
    };
    int p_count = 0;
    while ((choice = getopt_long(argc, argv, "c:f:o:vsp:h", long_options, 
        &option_index)) != -1) {
        switch (choice) {
        case 'h':
            printHelp();
            exit(0);

        case 'c':
            mode = optarg;
            if (mode != "stack" && mode != "queue") {
                exit(1);
            }
            cmds.c_sq = mode;
            break;

        case 'f':
            mode = optarg;
            if (mode != "stack" && mode != "queue") {
                exit(1);
            }
            cmds.f_sq = mode;
            break;

        case 'o':
            mode = optarg;
            if (mode.size() != 4) {
                exit(1);
            }
            else if (count(mode.begin(), mode.end(), 'n') != 1) {
                exit(1);
            }
            else if (count(mode.begin(), mode.end(), 's') != 1) {
                exit(1);
            }
            else if (count(mode.begin(), mode.end(), 'e') != 1) {
                exit(1);
            }
            else if (count(mode.begin(), mode.end(), 'w') != 1) {
                exit(1);
            }
            cmds.hunt_order = mode;
            break;

        case 'v':
            cmds.verb = true;
            break;

        case 's':
            cmds.stats = true;
            break;

        case 'p':
            if (p_count > 0) {
                exit(1);
            }
            mode = optarg;
            if (mode == "M" || mode == "L") {
                cmds.show_path = mode;
                ++p_count;
                break;
            }
            exit(1);

        default:
            exit(1);
        } // switch
    } // while

    return cmds;
} // getMode()

int main(int argc, char* argv[]) {
    ios_base::sync_with_stdio(false);
    cmdline opts = getCmd(argc, argv);
    string map_type;

    cin >> map_type;
    while (map_type != "M" && map_type != "L") {
        getline(cin, map_type);
        cin >> map_type;
    }
    int map_size = 0;
    cin >> map_size;

    Hunt result(map_size, map_type, opts.verb);
    
    result.read_map();

    result.captain_sq_hunt(opts.c_sq, opts.f_sq, opts.hunt_order);

    if (result.treas_found()) {
        result.get_path();
    }

    if (opts.verb) {
        result.print_verbose();
    }

    if (opts.stats) {
        cout << "--- STATS ---\n"
            << "Starting location: " << result.get_start_loc().row << ","
            << result.get_start_loc().col << "\n"
            << "Water locations investigated: " << result.get_water_invest()
            << "\n"
            << "Land locations investigated: " << result.get_land_invest()
            << "\n"
            << "Went ashore: " << result.get_num_ashore()
            << "\n";
        if (result.treas_found()) {
            cout << "Path length: " << result.path_length()
                << "\n"
                << "Treasure location: " << result.get_treas_loc().row << ","
                << result.get_treas_loc().col << "\n";
        }
        cout << "--- STATS ---\n";
    }

    if (opts.show_path == "M" && result.treas_found()) {
        result.print_map();
    }
    else if (opts.show_path == "L" && result.treas_found()) {
        result.print_map_list();
    }
    result.print_treas_result();

    return 0;
}