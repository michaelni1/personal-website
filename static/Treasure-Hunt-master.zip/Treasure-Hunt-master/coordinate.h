// PROJECT IDENTIFIER: 40FB54C86566B9DDEAB902CC80E8CE85C1C62AAD
#pragma once
#ifndef COORD_H
#define COORD_H

struct Coordinate {
    Coordinate() {}
    Coordinate(int row_in, int col_in) : row(row_in), col(col_in) {}
    int row = 0;
    int col = 0;
};

inline bool operator==(const Coordinate& lhs, const Coordinate& rhs) {
    return rhs.row == lhs.row && rhs.col == lhs.col;
}

struct Tile {
    Tile() {}
    Tile(char terrain_in) : terrain(terrain_in) {}
    char dir = '!';
    char terrain = '.';
};
#endif