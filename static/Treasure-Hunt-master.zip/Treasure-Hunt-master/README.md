# Treasure-Hunt

This program will find a path to a given treasure location using a stack or queue.

On the command line, type:

$ make

This will create an executable C++ file.<br />

Create a text file and at the top type L or M as the map type. L is for a list of coordinates, and M is for a visual map.<br /><br />
Below that, give a number n so that the map size is n x n.<br /><br />
Create a map using the following key:<br /><br />
1 of $ as the treasure location<br />
1 of @ as the starting location<br />
. as water location<br />
o as land location<br />
'#' as impassable location<br /><br />
E.g.:<br />
$oo<br />
o#.<br />
oo@<br /><br />
Your final file should look similar to:<br />
M<br />
3<br />
$oo<br />
o#.<br />
oo@<br />
<br />
Or provide a list of coordinates:<br />
E.g. 0 0 @<br /><br /><br />

Run the program with ./hunt [options] < [input text file]

where options are the following:

Help:<br />
-h
<br /><br />
Captain search order:<br />
-c queue<br />
-c stack<br />
<br />
First-mate search order:<br />
-f queue<br />
-f stack<br />
<br />
Search direction order:<br />
-o [nesw]<br />
<br />
Verbose output:<br />
-v<br />
<br />
Stats:<br />
-s<br />
<br />
Path output:<br />
-pM<br />
-pL<br />
<br />
Have fun!
