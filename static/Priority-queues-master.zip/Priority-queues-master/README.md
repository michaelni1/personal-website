# Priority-queues

Implementation of priority queue using different underlying structures.<br /><br />
BinaryPQ.h: array-based priority queue<br />
PairingPQ.h: pointer-based with melding to the root<br />
SortedPQ.h: array-based with std::sort
