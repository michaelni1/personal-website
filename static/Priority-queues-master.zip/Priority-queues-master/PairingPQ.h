// Project identifier: 9504853406CBAC39EE89AA3AD238AA12CA198043

#ifndef PAIRINGPQ_H
#define PAIRINGPQ_H

#include "Eecs281PQ.h"
#include <deque>
#include <utility>

// A specialized version of the 'priority_queue' ADT implemented as a pairing heap.
template<typename TYPE, typename COMP_FUNCTOR = std::less<TYPE>>
class PairingPQ : public Eecs281PQ<TYPE, COMP_FUNCTOR> {
    // This is a way to refer to the base class object.
    using BaseClass = Eecs281PQ<TYPE, COMP_FUNCTOR>;

public:
    // Each node within the pairing heap
    class Node {
        public:
            // TODO: After you add add one extra pointer (see below), be sure to
            // initialize it here.
            explicit Node(const TYPE &val)
                : elt{ val }, child{ nullptr }, sibling{ nullptr }, parent { nullptr }
            {}

            // Description: Allows access to the element at that Node's position.
			// There are two versions, getElt() and a dereference operator, use
			// whichever one seems more natural to you.
            // Runtime: O(1) - this has been provided for you.
            const TYPE &getElt() const { return elt; }
            const TYPE &operator*() const { return elt; }

            // The following line allows you to access any private data members of this
            // Node class from within the PairingPQ class. (ie: myNode.elt is a legal
            // statement in PairingPQ's add_node() function).
            friend PairingPQ;

        private:
            TYPE elt;
            Node *child;
            Node *sibling;
            Node* parent;
            // TODO: Add one extra pointer (parent or previous) as desired.
    }; // Node


    // Description: Construct an empty priority_queue with an optional comparison functor.
    // Runtime: O(1)
    explicit PairingPQ(COMP_FUNCTOR comp = COMP_FUNCTOR()) :
        BaseClass{ comp } {
    } // PairingPQ()


    // Description: Construct a priority_queue out of an iterator range with an optional
    //              comparison functor.
    // Runtime: O(n) where n is number of elements in range.
    // TODO: when you implement this function, uncomment the parameter names.
    template<typename InputIterator>
    PairingPQ(InputIterator start, InputIterator end, COMP_FUNCTOR comp = COMP_FUNCTOR()) :
        BaseClass{ comp } {
        for (auto it = start; it != end; ++it) {
            push(*it);
        }
    } // PairingPQ()


    // Description: Copy constructor.
    // Runtime: O(n)
    PairingPQ(const PairingPQ& other) :
        BaseClass{ other.compare } {
        std::deque<Node*> trees;
        trees.push_back(other.root);
        while (!trees.empty()) {
            Node* cur_node = trees.front();
            if (cur_node->child) {
                trees.push_back(cur_node->child);
            }
            if (cur_node->sibling) {
                trees.push_back(cur_node->sibling);
            }
            push(cur_node->elt);
            trees.pop_front();
        }
        heap_size = other.heap_size;
    } // PairingPQ()


    // Description: Copy assignment operator.
    // Runtime: O(n)
    // TODO: when you implement this function, uncomment the parameter names.
    PairingPQ& operator=(const PairingPQ& rhs) {
        if (this == &rhs) {
            return *this;
        }
        PairingPQ copy(rhs);
        std::swap(root, copy.root);
        heap_size = rhs.heap_size;
        return *this;
    } // operator=()


    // Description: Destructor
    // Runtime: O(n)
    ~PairingPQ() {
        if (root) {
            std::deque<Node*> trees;
            trees.push_back(root);
            while (!trees.empty()) {
                Node* cur_node = trees.front();
                if (cur_node->child) {
                    trees.push_back(cur_node->child);
                }
                if (cur_node->sibling) {
                    trees.push_back(cur_node->sibling);
                }
                delete cur_node;
                trees.pop_front();
            }
            root = nullptr;
        }
    } // ~PairingPQ()


    // Description: Assumes that all elements inside the priority_queue are out of order and
    //              'rebuilds' the priority_queue by fixing the priority_queue invariant.
    // Runtime: O(n)
    virtual void updatePriorities() {
        std::deque<Node*> trees;

        Node* root_node = root;
        trees.push_back(root_node);
        root = nullptr;

        while (!trees.empty()) {
            if (trees.front()->child) {
                trees.push_back(trees.front()->child);
            }
            if (trees.front()->sibling) {
                trees.push_back(trees.front()->sibling);
            }
            trees.front()->child = nullptr;
            trees.front()->sibling = nullptr;
            trees.front()->parent = nullptr;
            root_node = meld(root_node, trees.front());
            trees.pop_front();
        }
        root = root_node;
    } // updatePriorities()


    // Description: Add a new element to the priority_queue. This is almost done,
    //              in that you should implement push functionality in the addNode()
    //              function, and this function should call addNode().
    // Runtime: O(1)
    // TODO: when you implement this function, uncomment the parameter names.
    virtual void push(const TYPE & val) {
        addNode(val);
    } // push()


    // Description: Remove the most extreme (defined by 'compare') element from
    //              the priority_queue.
    // Note: We will not run tests on your code that would require it to pop an
    // element when the priority_queue is empty. Though you are welcome to if you are
    // familiar with them, you do not need to use exceptions in this project.
    // Runtime: Amortized O(log(n))
    virtual void pop() {
        --heap_size;
        //root doesn't have a child, so just return
        if (!root->child) {
            delete root;
            root = nullptr;
            return;
        }
        //root's child doesn't have a sibling, so only make
        //root's child the root
        /*if (!root->child->sibling && !root->child->child) {
            Node* saved_child = root->child;
            delete root;
            root = saved_child;
            root->child = nullptr;
            return;
        }*/
        std::deque<Node*> trees;
        Node* saved_node = root->child;
        delete root;
        saved_node->parent = nullptr;
        root = nullptr;

        trees.push_back(saved_node);
        while (saved_node->sibling) {
            trees.push_back(saved_node->sibling);
            saved_node->sibling = nullptr;
            saved_node->parent = nullptr;
            saved_node = trees.back();
        }
        saved_node->parent = nullptr;
        while (trees.size() != 1) {
            Node* saved_front = trees.front();
            trees.pop_front();
            Node* saved_next = trees.front();
            trees.pop_front();
            trees.push_back(meld(saved_front, saved_next));
        }
        root = trees.front();
    } // pop()


    // Description: Return the most extreme (defined by 'compare') element of
    //              the heap.  This should be a reference for speed.  It MUST be
    //              const because we cannot allow it to be modified, as that
    //              might make it no longer be the most extreme element.
    // Runtime: O(1)
    virtual const TYPE & top() const {
        return root->elt;
    } // top()


    // Description: Get the number of elements in the priority_queue.
    // Runtime: O(1)
    virtual std::size_t size() const {
        return heap_size;
    } // size()

    // Description: Return true if the priority_queue is empty.
    // Runtime: O(1)
    virtual bool empty() const {
        return heap_size == 0;
    } // empty()


    // Description: Updates the priority of an element already in the priority_queue by
    //              replacing the element refered to by the Node with new_value.
    //              Must maintain priority_queue invariants.
    //
    // PRECONDITION: The new priority, given by 'new_value' must be more extreme
    //               (as defined by comp) than the old priority.
    //
    // Runtime: As discussed in reading material.
    // TODO: when you implement this function, uncomment the parameter names.
    void updateElt(Node* node, const TYPE & new_value) {
        if (node == root) {
            root->elt = new_value;
            return;
        }
        node->elt = new_value;
        Node* parent = node->parent;
        if (this->compare(parent->elt, new_value)) {
            node->parent = nullptr;
            if (parent->child == node) {
                if (node->sibling) {
                    parent->child = node->sibling;
                }
                else {
                    parent->child = nullptr;
                }
            }
            else {
                Node* one_b4 = parent->child;
                while (one_b4->sibling != node) {
                    one_b4 = one_b4->sibling;
                }
                if (node->sibling) {
                    one_b4->sibling = node->sibling;
                }
                else {
                    one_b4->sibling = nullptr;
                }
            }
            node->sibling = nullptr;
            root = meld(root, node);
        }
    } // updateElt()


    // Description: Add a new element to the priority_queue. Returns a Node* corresponding
    //              to the newly added element.
    // Runtime: O(1)
    // TODO: when you implement this function, uncomment the parameter names.
    // NOTE: Whenever you create a node, and thus return a Node *, you must be sure to
    //       never move or copy/delete that node in the future, until it is eliminated
    //       by the user calling pop().  Remember this when you implement updateElt() and
    //       updatePriorities().
    Node* addNode(const TYPE & val) {
        Node* val_in = new Node(val);
        if (!root) {
            root = val_in;
        }
        root = meld(root, val_in);
        ++heap_size;
        return val_in;
    } // addNode()


private:
    size_t heap_size = 0;
    Node* root = nullptr;
    Node* meld(Node* lhs_root, Node* rhs_root) {
        if (lhs_root == rhs_root) {
            return lhs_root;
        }
        else if (this->compare(rhs_root->elt, lhs_root->elt)) {
            rhs_root->parent = lhs_root;
            rhs_root->sibling = lhs_root->child;
            lhs_root->child = rhs_root;
            return lhs_root;
        }
        else {
            lhs_root->parent = rhs_root;
            lhs_root->sibling = rhs_root->child;
            rhs_root->child = lhs_root;
            return rhs_root;
        }
    }
    // TODO: Add any additional member functions or data you require here.
    // TODO: We recommend creating a 'meld' function (see the Pairing Heap papers).
};


#endif // PAIRINGPQ_H
