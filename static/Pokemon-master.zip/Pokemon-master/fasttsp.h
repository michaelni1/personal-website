// Project Identifier: 5949F553E20B650AB0FB2266D3C0822B13D248B0
#pragma once

#include "coordinate.h"
#include <vector>
#include <iostream>
#include <math.h>
#include <limits>
#include <deque>
#include <unordered_map>

class fastTSP {
public:
    void read_coordinates();

    void run_nearest_arbitrary_insertion();

    void print_result();

    double tsp_get_distance(fastTSP_Coordinate& lhs, fastTSP_Coordinate& rhs) {
        //distance between two coordinates
        return sqrt((((double)lhs.x - rhs.x) * ((double)lhs.x - rhs.x)) + (((double)lhs.y - rhs.y) * ((double)lhs.y - rhs.y)));
    }

private:
    vector<fastTSP_Coordinate> map;
    vector<vector<fastTSP_Coordinate>::iterator> sub_tour;
};