//Project Identifier: 5949F553E20B650AB0FB2266D3C0822B13D248B0

#include "fasttsp.h"
#include "coordinate.h"

void fastTSP::read_coordinates() {
    size_t num_poke;
    cin >> num_poke;
    map.reserve(num_poke);
    int x = 0;
    int y = 0;
    while (cin >> x) {
        cin >> y;
        map.push_back(fastTSP_Coordinate(x, y));
    }
}

void fastTSP::run_nearest_arbitrary_insertion() {
    //at least map.size() edges or else it would be MST
    sub_tour.reserve(map.size());
    //insert first tour to itself to begin loop
    sub_tour.push_back(map.begin());
    sub_tour.push_back(map.begin());
    for (auto map_it = map.begin() + 1; map_it != map.end(); ++map_it) {
        double least = numeric_limits<double>::infinity();
        auto nearest_edge = sub_tour.end();
        //find edges that minimize distance(i->k) + distance(k->j) - distance(i->j)
        for (auto tour_it = sub_tour.begin(); tour_it != sub_tour.end() - 1; ++tour_it) {
            //choose arbitrary coordinate map_it, which is from beginning to end of map vector;
            double current = tsp_get_distance(**tour_it, *map_it) + tsp_get_distance(*map_it, **(tour_it + 1))
                - tsp_get_distance(**tour_it, **(tour_it + 1));
            //if current less than least distance(i->k) + distance(k->j) - distance(i->j), update least
            if (current < least) {
                least = current;
                nearest_edge = tour_it;
            }
        }
        //insert coordinates; nearest_edge + 1 because insertion is before iterator
        sub_tour.insert(nearest_edge + 1, map_it);
    }
}

void fastTSP::print_result() {
    double total_weight = 0;
    for (auto it = sub_tour.begin(); it != sub_tour.end() - 1; ++it) {
        total_weight += tsp_get_distance(**it, **(it + 1));
    }
    cout << total_weight << "\n";
    for (auto it = sub_tour.begin(); it != sub_tour.end() - 1; ++it) {
        cout << *it - map.begin() << " ";
    }
}