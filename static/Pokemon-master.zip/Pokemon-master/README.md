# Pokemon

Connecting a list of coordinates (pokemon) in a minimum spanning tree, fast TSP map, or optimal TSP map.
<br /><br />
$ make
<br /><br />
$ ./poke -m [MST, FASTTSP, or OPTTSP] < [input file]
<br /><br />
Please structure your input file like this:<br />
7<br />
7 7<br />
-5 0<br />
-3 -3<br />
-6 -1<br />
-2 -3<br />
-5 -4<br />
-1 -6<br />
<br />
where each row is a coordinate and the first row is the number of coordinates.<br /><br />
The output will give the total path length and the best route for the chosen mode.
