// Project Identifier: 5949F553E20B650AB0FB2266D3C0822B13D248B0
#pragma once

#include "coordinate.h"
#include <vector>
#include <iostream>
#include <math.h>
#include <limits>

using namespace std;

class MST {
public:
    bool is_invalid_map() {
        return pokemon_on_coast && pokemon_on_land && !pokemon_on_coast;
    }

    void read_coordinates();

    void run_primm();

    void print_result();

private:
    vector<MST_Coordinate> map;
    bool pokemon_on_coast = false;
    bool pokemon_on_land = false;
    bool pokemon_on_water = false;
};