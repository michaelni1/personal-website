// Project Identifier: 5949F553E20B650AB0FB2266D3C0822B13D248B0
#pragma once

#include <string>
#include <limits>

using namespace std;

struct MST_Coordinate {
    double dist = numeric_limits<double>::infinity();
    int x = -1;
    int y = -1;
    int parent_index = -1;
    bool visited = false;
    bool land = false;
    bool water = false;

    MST_Coordinate() {}
    MST_Coordinate(int x_in, int y_in, bool land_in, bool water_in)
        : x(x_in), y(y_in), land(land_in), water(water_in) {}

    double get_distance(MST_Coordinate& rhs) {
        if ((land && rhs.water) || (water && rhs.land)) {
            return numeric_limits<double>::infinity();
        }
        return (((double)x - rhs.x) * ((double)x - rhs.x)) + (((double)y - rhs.y) * ((double)y - rhs.y));
    }
};

struct fastTSP_Coordinate {
    int x = 0;
    int y = 0;

    fastTSP_Coordinate() {}
    fastTSP_Coordinate(int x_in, int y_in)
        : x(x_in), y(y_in) {}
};

struct optTSP_Coordinate {
    double dist = numeric_limits<double>::infinity();
    int x = 0;
    int y = 0;
    bool visited = false;

    optTSP_Coordinate () {}
    optTSP_Coordinate(int x_in, int y_in)
        : x(x_in), y(y_in) {}
};