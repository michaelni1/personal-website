// Project Identifier: 5949F553E20B650AB0FB2266D3C0822B13D248B0
#include "mst.h"

void MST::read_coordinates() {
    size_t num_poke;
    cin >> num_poke;
    map.reserve(num_poke);
    int x = 0;
    int y = 0;
    while (cin >> x) {
        cin >> y;
        if (x < 0 && y < 0) {
            MST_Coordinate in(x, y, false, true);
            map.push_back(in);
            pokemon_on_water = true;
        }
        else if ((x <= 0 && y == 0) || (x == 0 && y <= 0)) {
            MST_Coordinate in(x, y, false, false);
            map.push_back(in);
            pokemon_on_coast = true;
        }
        else {
            MST_Coordinate in(x, y, true, false);
            map.push_back(in);
            pokemon_on_land = true;
        }
    }
}

void MST::run_primm() {
    map[0].dist = 0;
    auto least_coord = map.end();
    double least_dist = numeric_limits<double>::infinity();
    for (size_t i = 0; i < map.size(); ++i) {
        //step 1, find least distance coordinate
        for (auto it1 = map.begin(); it1 != map.end(); ++it1) {
            if (!it1->visited) {
                if (it1->dist < least_dist) {
                    least_coord = it1;
                    least_dist = it1->dist;
                }
            }
        }
        int least_index = (int)(least_coord - map.begin());
        //step 2, set v to visited
        least_coord->visited = true;
        //step 3, update neighbors
        for (auto it2 = map.begin(); it2 != map.end(); ++it2) {
            if (!it2->visited) {
                //update distance between the least distance coordinate and rest of unvisited nodes
                double least_to_it2 = least_coord->get_distance(*it2);
                if (least_to_it2 < it2->dist) {
                    it2->dist = least_to_it2;
                    it2->parent_index = least_index;
                }
            }
        }
        //reset least_dist
        least_dist = numeric_limits<double>::infinity();
    }
}

void MST::print_result() {
    double total_weight = 0;
    for (auto it = map.begin(); it != map.end(); ++it) {
        total_weight += sqrt(it->dist);
    }
    cout << total_weight << "\n";
    int index = 1;
    for (auto it = map.begin() + 1; it != map.end(); ++it) {
        if (index < it->parent_index) {
            cout << index << " " << it->parent_index << "\n";
        }
        else {
            cout << it->parent_index << " " << index << "\n";
        }
        ++index;
    }
}