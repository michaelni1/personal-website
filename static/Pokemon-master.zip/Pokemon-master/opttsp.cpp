//Project Identifier: 5949F553E20B650AB0FB2266D3C0822B13D248B0
#include "opttsp.h"

void optTSP::read_coordinates() {
    size_t num_poke;
    cin >> num_poke;
    map.reserve(num_poke);
    distance_matrix.resize(num_poke, vector<double>(num_poke));
    int x = 0;
    int y = 0;
    while (cin >> x) {
        cin >> y;
        map.push_back(optTSP_Coordinate(x, y));
    }
    for (size_t i = 0; i < distance_matrix.size(); ++i) {
        for (size_t j = 0; j < distance_matrix.size(); ++j) {
            distance_matrix[i][j] = tsp_get_distance(map[i], map[j]);
        }
    }
}

double optTSP::run_primm(size_t perm_length) {
    //set initial vertex distance to 0
    map[*(cur_tour.begin() + perm_length)].dist = 0;
    auto least_coord = cur_tour.end();
    double least_dist = numeric_limits<double>::infinity();
    double arm_begin = numeric_limits<double>::infinity();
    double arm_end = numeric_limits<double>::infinity();
    double path_length = 0;
    //start at perm_length, because that is first unvisited node
    for (size_t i = perm_length; i < cur_tour.size(); ++i) {
        //step 1, find least distance coordinate
        for (auto it1 = cur_tour.begin() + perm_length; it1 != cur_tour.end(); ++it1) {
            if (!map[*it1].visited) {
                //if it1 distance is less than least distance, update least distance
                if (map[*it1].dist < least_dist) {
                    least_coord = it1;
                    least_dist = map[*it1].dist;
                }
            }
        }
        //step 2, set v to visited
        map[*least_coord].visited = true;
        //update path_length of MST
        path_length += map[*least_coord].dist;
        //update arms
        double least_to_arm_begin = distance_matrix[*cur_tour.begin()][*least_coord];
        if (least_to_arm_begin < arm_begin) {
            arm_begin = least_to_arm_begin;
        }
        //perm_length - 1 is last visited node
        double least_to_arm_end = distance_matrix[*(cur_tour.begin() + perm_length - 1)][*least_coord];
        if (least_to_arm_end < arm_end) {
            arm_end = least_to_arm_end;
        }
        //step 3, update neighbors
        for (auto it2 = cur_tour.begin() + perm_length; it2 != cur_tour.end(); ++it2) {
            if (!map[*it2].visited) {
                //update distance between the least distance coordinate and rest of unvisited nodes
                double least_coord_to_it2 = distance_matrix[*it2][*least_coord];
                if (least_coord_to_it2 < map[*it2].dist) {
                    map[*it2].dist = least_coord_to_it2;
                }
            }
        }
        //reset least_dist
        least_dist = numeric_limits<double>::infinity();
    }
    //reset node visited and distance
    for (auto tour_it = cur_tour.begin() + perm_length; tour_it != cur_tour.end(); ++tour_it) {
        map[*tour_it].dist = numeric_limits<double>::infinity();
        map[*tour_it].visited = false;
    }
    //add arms to path_length
    path_length += arm_begin + arm_end;
    //return MST distance
    return path_length;
}

bool optTSP::promising(size_t perm_length) {
    if (cur_tour.size() - perm_length < 5) {
        return true;
    }
    //run_primm() returns MST length + current_distance
    if (run_primm(perm_length) + cur_dist > best_dist) {
        return false;
    }
    return true;
}

void optTSP::genPerms(size_t perm_length) {
    if (perm_length == map.size()) {
        //add distance from end->beginning of path to complete cycle
        double cur_dist_in = distance_matrix[*cur_tour.rbegin()][*cur_tour.begin()];
        cur_dist += cur_dist_in;
        if (cur_dist < best_dist) {
            best_dist = cur_dist;
            best_tour = cur_tour;
        }
        //subtract end->beginning distance out to stay consistent with rest of algorithm
        cur_dist -= cur_dist_in;
        return;
    }
    if (!promising(perm_length)) {
        return;
    }
    for (size_t i = perm_length; i < map.size(); ++i) {
        swap(cur_tour[perm_length], cur_tour[i]);
        cur_dist += distance_matrix[*(cur_tour.begin() + perm_length - 1)][*(cur_tour.begin() + perm_length)];

        genPerms(perm_length + 1);

        cur_dist -= distance_matrix[*(cur_tour.begin() + perm_length - 1)][*(cur_tour.begin() + perm_length)];
        swap(cur_tour[perm_length], cur_tour[i]);
    }
}

void optTSP::set_upper_bound() {
    //at least map.size() edges or else it would be MST
    cur_tour.reserve(map.size() + 1);
    //insert first tour to begin self-loop
    cur_tour.push_back(0);
    cur_tour.push_back(1);
    cur_tour.push_back(2);
    cur_tour.push_back(0);
    //choose arbitrary coordinate map_it, which is from beginning + 1 to end of map vector;
    for (size_t map_index = 3; map_index < map.size(); ++map_index) {
        double least = numeric_limits<double>::infinity();
        auto nearest_edge = cur_tour.end();
        //find edges that minimize distance(i->k) + distance(k->j) - distance(i->j)
        for (auto tour_it = cur_tour.begin(); tour_it != cur_tour.end() - 1; ++tour_it) {
            //find index in map vector that minimizes distances i->k + k->j - i->j
            double current = distance_matrix[*tour_it][map_index] + distance_matrix[map_index][*(tour_it + 1)]
                - distance_matrix[*tour_it][*(tour_it + 1)];
            //if current less than least distance(i->k) + distance(k->j) - distance(i->j), update least
            if (current < least) {
                least = current;
                nearest_edge = tour_it;
            }
        }
        //insert coordinates; nearest_edge + 1 because insertion is before iterator
        cur_tour.insert(nearest_edge + 1, map_index);
    }
    //add up distances for upper bound
    for (auto tour_it = cur_tour.begin(); tour_it != cur_tour.end() - 1; ++tour_it) {
        best_dist += distance_matrix[*tour_it][*(tour_it + 1)];
    }
    //pop_back() to ensure that cur_tour is consistent with genPerms and MST algorithm range
    cur_tour.pop_back();
    //copy over cur_tour to best_tour
    best_tour.reserve(cur_tour.size());
    best_tour = cur_tour;
}

void optTSP::run_opt_tsp() {
    set_upper_bound();
    genPerms(1);
}

void optTSP::print_result() {
    cout << best_dist << "\n";
    for (auto it = best_tour.begin(); it != best_tour.end(); ++it) {
        cout << *it << " ";
    }
}