//Project Identifier: 5949F553E20B650AB0FB2266D3C0822B13D248B0
#pragma once

#include "coordinate.h"
#include <vector>
#include <iostream>
#include <math.h>
#include <numeric>

using namespace std;

class optTSP {
public:
    void read_coordinates();

    bool promising(size_t perm_length);

    double run_primm(size_t perm_length);

    void genPerms(size_t perm_length);

    void run_opt_tsp();

    void set_upper_bound();
    
    void print_result();

    double tsp_get_distance(optTSP_Coordinate& lhs, optTSP_Coordinate& rhs) {
        //distance between two coordinates
        return sqrt((((double)lhs.x - rhs.x) * ((double)lhs.x - rhs.x)) + (((double)lhs.y - rhs.y) * ((double)lhs.y - rhs.y)));
    }

private:
    vector<vector<double>> distance_matrix;
    vector<optTSP_Coordinate> map;
    vector<size_t> best_tour;
    vector<size_t> cur_tour;
    double best_dist = 0;
    double cur_dist = 0;
};