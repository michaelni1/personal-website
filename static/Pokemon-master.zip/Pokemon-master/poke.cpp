// Project Identifier: 5949F553E20B650AB0FB2266D3C0822B13D248B0
#include <getopt.h>
#include <string>
#include <iostream>
#include <iomanip>
#include <limits>
#include "mst.h"
#include "fasttsp.h"
#include "opttsp.h"

using namespace std;

struct cmdline {
    bool mst = false;
    bool fasttsp = false;
    bool opttsp = false;
};

// Print help for the user when requested.
// argv[0] is the name of the currently executing program
void printHelp() {
    cout << "usage: ./poke -m, --mode <MODE>\n";
} // printHelp()

// Process the command line; the only thing we need to return is the mode
// when the user specifies the -m/--mode option.
// return struct?
cmdline getCmd(int argc, char* argv[]) {
    cmdline cmds;

    // These are used with getopt_long()
    int choice;
    int option_index = 0;
    string mode = "";
    option long_options[] = {
        // TODO: Fill in two lines, for the "mode" ('m') and
        // the "help" ('h') options.
        { "mode", required_argument, nullptr, 'm' },
        { "help", no_argument,       nullptr, 'h' },
        { nullptr, 0,                nullptr, '\0' }
    };
    while ((choice = getopt_long(argc, argv, "m:h", long_options,
        &option_index)) != -1) {
        switch (choice) {
        case 'h':
            printHelp();
            exit(0);

        case 'm':
            mode = optarg;
            if (mode == "MST") {
                cmds.mst = true;
            }
            else if (mode == "FASTTSP") {
                cmds.fasttsp = true;
            }
            else if (mode == "OPTTSP") {
                cmds.opttsp = true;
            }
            break;

        default:
            exit(1);
        } // switch
    } // while

    return cmds;
} // getMode()

int main(int argc, char* argv[]) {
    ios_base::sync_with_stdio(false);
    cout << std::setprecision(2); //Always show 2 decimal places
    cout << std::fixed; //Disable scientific notation for large numbers
    cmdline opts = getCmd(argc, argv);

    if (opts.mst) {
        MST result;
        result.read_coordinates();
        if (!result.is_invalid_map()) {
            result.run_primm();
            result.print_result();
        }
        else {
            cerr << "Cannot construct MST";
            exit(1);
        }
    }
    else if (opts.fasttsp) {
        fastTSP result;
        result.read_coordinates();
        result.run_nearest_arbitrary_insertion();
        result.print_result();
    }
    else if (opts.opttsp) {
        optTSP result;
        result.read_coordinates();
        result.run_opt_tsp();
        result.print_result();
    }
    return 0;
}