// PROJECT IDENTIFIER : 9504853406CBAC39EE89AA3AD238AA12CA198043

#include <getopt.h>
#include <string>
#include <iostream>
#include "P2random.h"
#include "battle.h"

using namespace std;

struct cmdline {
    bool verb = false;
    size_t stats = 0;
    bool median = false;
};

// Print help for the user when requested.
// argv[0] is the name of the currently executing program
void printHelp() {
    cout << "usage: ./zombbb [options] [inputfile]\n";
} // printHelp()

// Process the command line; the only thing we need to return is the mode
// when the user specifies the -m/--mode option.
// return struct?
cmdline getCmd(int argc, char* argv[]) {
    cmdline cmds;

    // These are used with getopt_long()
    int choice;
    int option_index = 0;
    option long_options[] = {
        // TODO: Fill in two lines, for the "mode" ('m') and
        // the "help" ('h') options.
        { "verbose", no_argument, nullptr, 'v' },
        { "statistics", required_argument, nullptr, 's' },
        { "median", no_argument, nullptr, 'm' },
        { "help", no_argument,       nullptr, 'h' },
        { nullptr, 0,                nullptr, '\0' }
    };
    while ((choice = getopt_long(argc, argv, "vs:mh", long_options,
        &option_index)) != -1) {
        switch (choice) {
        case 'h':
            printHelp();
            exit(0);

        case 'v':
            cmds.verb = true;
            break;

        case 's':
            cmds.stats = atoi(optarg);
            break;

        case 'm':
            cmds.median = true;
            break;

        default:
            exit(1);
        } // switch
    } // while

    return cmds;
} // getMode()

int main(int argc, char* argv[]) {
    ios_base::sync_with_stdio(false);
    cmdline opts = getCmd(argc, argv);
    string junk = "";
    unsigned int quiver_capacity = 0;
    unsigned int random_seed = 0;
    unsigned int max_rand_dist = 0;
    unsigned int max_rand_speed = 0;
    unsigned int max_rand_heal = 0;

    getline(cin, junk);
    cin >> junk;
    cin >> quiver_capacity;
    cin >> junk;
    cin >> random_seed;
    cin >> junk;
    cin >> max_rand_dist;
    cin >> junk;
    cin >> max_rand_speed;
    cin >> junk;
    cin >> max_rand_heal;
    P2random::initialize(random_seed, max_rand_dist, max_rand_speed, max_rand_heal);

    unsigned int round = 0;
    unsigned int rand_num = 0;
    unsigned int named_num = 0;
    string name = "";
    unsigned int dist = 0;
    unsigned int speed = 0;
    unsigned int health = 0;
    unsigned int total_zombs = 0;
    deque<Zombie*> named_zombs;
    vector<Round> round_data;
    while (cin >> junk) {
        cin >> junk;
        cin >> round;
        cin >> junk;
        cin >> rand_num;
        cin >> junk;
        cin >> named_num;
        for (unsigned int i = 0; i < named_num; ++i) {
            cin >> name;
            cin >> junk;
            cin >> dist;
            cin >> junk;
            cin >> speed;
            cin >> junk;
            cin >> health;
            Zombie *ptr = new Zombie(name, dist, speed, health);
            named_zombs.push_back(ptr);
        }
        Round in(round, rand_num, named_num);
        round_data.push_back(in);
        total_zombs += rand_num + named_num;
    }
    deque<Zombie*>* named_ptr = &named_zombs;
    Battle result(named_ptr, round_data, quiver_capacity, opts.stats, total_zombs, opts.verb, opts.median);
    result.combat_r1();
    result.combat_all_r();
    result.delete_zombs();

    return 0;
}