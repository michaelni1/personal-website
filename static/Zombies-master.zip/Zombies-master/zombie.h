// PROJECT IDENTIFIER : 9504853406CBAC39EE89AA3AD238AA12CA198043

#pragma once
#include <string>

using namespace std;

struct Round {
    Round(unsigned int round_in, unsigned int rand_num_in, unsigned int num_named_in)
        : round(round_in), rand_num(rand_num_in), named_num(num_named_in) {}
    
    unsigned int round = 1;
    unsigned int rand_num = 0;
    unsigned int named_num = 0;
};

struct Zombie {
    Zombie() {}

    Zombie(string name_in, unsigned int dist_in, unsigned int speed_in, unsigned int health_in) 
        : name(name_in), distance(dist_in), speed(speed_in), health(health_in) {}

    string name = "";
    unsigned int distance = 0;
    unsigned int speed = 1;
    unsigned int health = 1;
    bool destroyed = false;
    unsigned int lifetime = 1;

    unsigned int get_eta() const {
        return distance / speed;
    }
};

class Compare {
public:
    bool operator()(const Zombie* lhs, const Zombie* rhs) {
        if (lhs->get_eta() == rhs->get_eta() && lhs->health != rhs->health) {
            return lhs->health > rhs->health;
        }
        if (lhs->get_eta() == rhs->get_eta() && lhs->health == rhs->health) {
            return lhs->name > rhs->name;
        }
        return lhs->get_eta() > rhs->get_eta();
    }
};

class MostActiveComp {
public:
    bool operator()(const Zombie* lhs, const Zombie* rhs) {
        if (lhs->lifetime == rhs->lifetime) {
            if (lhs->name < rhs->name) {
                return true;
            }
            return false;
        }
        return lhs->lifetime > rhs->lifetime;
    }
};

class LeastActiveComp {
public:
    bool operator()(const Zombie* lhs, const Zombie* rhs) {
        if (lhs->lifetime == rhs->lifetime) {
            if (lhs->name < rhs->name) {
                return true;
            }
            return false;
        }
        return lhs->lifetime < rhs->lifetime;
    }
};