# Zombies

Given a text file with specifications for zombie generation, we simulate a zombie-shooting game.

$ make

Please structure your input file like in this example:<br />
#test1<br />
quiver-capacity: 50<br />
random-seed: 99999991<br />
max-rand-distance: 1<br />
max-rand-speed: 1<br />
max-rand-health: 2<br />
---<br />
round: 1<br />
random-zombies: 5<br />
named-zombies: 3<br />
joe distance: 1 speed: 1 health: 5<br />
JOE distance: 2 speed: 1 health: 7<br />
joE distance: 5 speed: 1 health: 12<br />
---<br />
round: 2<br />
random-zombies: 5<br />
named-zombies: 2<br />
JamesDud-d+dkdsverstadt distance: 5 speed: 10 health: 20<br />
JamesDuddsaw@d$%^erstadt1 distance: 1 speed: 10 health: 50<br />
---<br />
round: 3<br />
random-zombies: 0<br />
named-zombies: 3<br />
jonebobz21 distance: 2 speed: 10 health: 2<br />
yoyoyo distance: 10 speed: 10 health: 1<br />
abcdzcdvxx distance: 20 speed: 10 health: 1<br />
<br /><br />
$ ./zombbb [options] [input file]<br /><br />
where options are:<br />
Verbose:<br />
-v<br /><br />
Stats:<br />
-s [number to display]<br /><br />
Median:<br />
-m
