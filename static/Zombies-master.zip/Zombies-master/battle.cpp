// PROJECT IDENTIFIER : 9504853406CBAC39EE89AA3AD238AA12CA198043
#include "battle.h"

using namespace std;

void Battle::generate_zombs(size_t r_index) {
    //generate randoms
    for (unsigned int i = 0; i < round_data[r_index].rand_num; ++i) {
        string name = P2random::getNextZombieName();
        unsigned int distance = P2random::getNextZombieDistance();
        unsigned int speed = P2random::getNextZombieSpeed();
        unsigned int health = P2random::getNextZombieHealth();
        Zombie* ptr = new Zombie(name, distance, speed, health);
        ordered_zombs.push_back(ptr);
        zombs.push(ptr);
        if (verb) {
            cout << "Created: " << ptr->name << " " << "(distance: " << ptr->distance
                << ", " << "speed: " << ptr->speed << ", " << "health: " << ptr->health << ")\n";
        }
    }
    //generate named
    for (unsigned int i = 0; i < round_data[r_index].named_num; ++i) {
        ordered_zombs.push_back(named_zombs->front());
        zombs.push(named_zombs->front());
        if (verb) {
            cout << "Created: " << named_zombs->front()->name << " " << "(distance: "
                << named_zombs->front()->distance << ", " << "speed: " << named_zombs->front()->speed
                << ", " << "health: " << named_zombs->front()->health << ")\n";
        }
        named_zombs->pop_front();
    }
}

void Battle::calc_median(unsigned int life_in) {
    //start by pushing first val to greatest_low_median
    if (greatest_low_med.size() == 0) {
        greatest_low_med.push(life_in);
    }
    //if life_in is greater than the greatest low value of running median,
    //add to least high values
    else if (life_in > greatest_low_med.top()) {
        least_high_med.push(life_in);
    }
    else if (life_in <= greatest_low_med.top()) {
        greatest_low_med.push(life_in);
    }
    //rebalancing; if greatest_low - least_high == 2, greatest_low has more
    //so add to least_high and pop from greatest_low
    if (greatest_low_med.size() - least_high_med.size() == 2) {
        least_high_med.push(greatest_low_med.top());
        greatest_low_med.pop();
    }
    //least_high has more, so add to greatest_low and pop from least_high
    if (least_high_med.size() - greatest_low_med.size() == 2) {
        greatest_low_med.push(least_high_med.top());
        least_high_med.pop();
    }
}

unsigned int Battle::get_median() {
    if (greatest_low_med.size() == least_high_med.size()) {
        return ((greatest_low_med.top() + least_high_med.top()) / 2);
    }
    else if (greatest_low_med.size() > least_high_med.size()) {
        return greatest_low_med.top();
    }
    return least_high_med.top();
}

void Battle::combat_r1() {
    unsigned int quiver = q_capacity;
    //keep incrementing round until it reaches "first" round
    while (round_data[r_data_check - 1].round != round) {
        if (verb) {
            cout << "Round: " << round << "\n";
        }
        ++round;
    }
    if (verb) {
        cout << "Round: " << round << "\n";
    }
    //generate zombies for first round
    generate_zombs(r_data_check - 1);
    while (!zombs.empty()) {
        while (zombs.top()->health != 0 && quiver != 0) {
            //subtract zombie health from quiver or vice versa
            if (zombs.top()->health >= quiver) {
                zombs.top()->health -= quiver;
                quiver = 0;
            }
            else {
                quiver -= zombs.top()->health;
                zombs.top()->health = 0;
            }
            //if zombie is destroyed/health == 0
            if (zombs.top()->health == 0) {
                if (verb) {
                    cout << "Destroyed: " << zombs.top()->name << " (distance: "
                        << zombs.top()->distance << ", speed: " << zombs.top()->speed
                        << ", health: 0)\n";
                }
                if (median) {
                    //add to running median
                    calc_median(zombs.top()->lifetime);
                }
                if (stats_num > 0) {
                    //add to killed zombies in order
                    killed_zombs.push_back(zombs.top());
                }
                //set zombie to destroyed
                zombs.top()->destroyed = true;
                //one_destroyed to check if median should be outputted
                one_destroyed = true;
                last_victim = zombs.top();
                zombs.pop();
            }
            if (zombs.empty()) {
                break;
            }
        }
        if (one_destroyed && median) {
            cout << "At the end of round " << round << ", the median zombie lifetime is " << get_median() << "\n";
        }
        if (quiver == 0) {
            break;
        }
    }
    ++r_data_check;
}

void Battle::combat_all_r() {
    unsigned int quiver = q_capacity;
    //initialize pointers to avoid error
    Zombie* killer = nullptr;
    bool eaten = false;
    while (!zombs.empty() || r_data_check <= round_data.size()) {
        ++round;
        if (verb) {
            cout << "Round: " << round << "\n";
        }
        quiver = q_capacity;
        //updating phase
        for (auto it = ordered_zombs.begin(); it != ordered_zombs.end(); ++it) {
            if (!(*it)->destroyed) {
                (*it)->distance = max(0, ((int)(*it)->distance - (int)(*it)->speed));
                (*it)->lifetime += 1;
                if (verb) {
                    cout << "Moved: " << (*it)->name << " " << "(distance: " << (*it)->distance << ", "
                        << "speed: " << (*it)->speed << ", " << "health: " << (*it)->health << ")\n";
                }
                if ((*it)->distance == 0 && !eaten) {
                    killer = *it;
                    eaten = true;
                }
            }
        }
        if (eaten) {
            cout << "DEFEAT IN ROUND " << round << "! " << killer->name << " ate your brains!";
            if (stats_num != 0) {
                print_stats();
            }
            break;
        }
        if (r_data_check <= round_data.size()) {
            if (round_data[r_data_check - 1].round == round) {
                generate_zombs(r_data_check - 1);
                ++r_data_check;
            }
        }
        //shooting phase
        if (!zombs.empty()) {
            while (zombs.top()->health != 0 && quiver != 0) {
                //subtract health from quiver or vice versa
                if (zombs.top()->health >= quiver) {
                    zombs.top()->health -= quiver;
                    quiver = 0;
                }
                else {
                    quiver -= zombs.top()->health;
                    zombs.top()->health = 0;
                }
                //if zombie health is 0
                if (zombs.top()->health == 0) {
                    if (verb) {
                        cout << "Destroyed: " << zombs.top()->name << " (distance: "
                            << zombs.top()->distance << ", speed: " << zombs.top()->speed
                            << ", health: 0)\n";
                    }
                    if (median) {
                        //input lifetime into running median
                        calc_median(zombs.top()->lifetime);
                    }
                    if (stats_num > 0) {
                        //if stats_num is selected
                        killed_zombs.push_back(zombs.top());
                    }
                    zombs.top()->destroyed = true;
                    one_destroyed = true;
                    last_victim = zombs.top();
                    zombs.pop();
                }
                if (zombs.empty()) {
                    break;
                }
            }
        }
        if (one_destroyed && median) {
            cout << "At the end of round " << round << ", the median zombie lifetime is " << get_median() << "\n";
        }
    }
    if (!eaten) {
        cout << "VICTORY IN ROUND " << round << "! " << last_victim->name << " was the last zombie.";
        if (stats_num != 0) {
            print_stats();
        }
    }
}

void Battle::print_stats() {
    size_t killed_stats = stats_num;
    size_t active_stats = stats_num;
    //set stats output to max size if it exceeds size
    if (stats_num > killed_zombs.size()) {
        killed_stats = killed_zombs.size();
    }
    if (stats_num > ordered_zombs.size()) {
        active_stats = ordered_zombs.size();
    }
    unsigned int still_active = 0;
    if (!zombs.empty()) {
        for (size_t i = 0; i < ordered_zombs.size(); ++i) {
            if (!ordered_zombs[i]->destroyed) {
                ++still_active;
            }
        }
    }
    cout << "\nZombies still active: " << still_active;
    cout << "\nFirst zombies killed:\n";
    size_t count = 1;
    for (auto it = killed_zombs.begin(); it != killed_zombs.begin() + killed_stats; ++it) {
        cout << (*it)->name << " " << count << "\n";
        ++count;
    }
    cout << "Last zombies killed:\n";
    --count;
    for (auto it = killed_zombs.rbegin(); it != killed_zombs.rbegin() + killed_stats; ++it) {
        cout << (*it)->name << " " << count << "\n";
        --count;
    }
    cout << "Most active zombies:\n";
    MostActiveComp most_comp;
    partial_sort(ordered_zombs.begin(), ordered_zombs.begin() + active_stats, ordered_zombs.end(), most_comp);
    for (auto it = ordered_zombs.begin(); it != ordered_zombs.begin() + active_stats; ++it) {
        cout << (*it)->name << " " << (*it)->lifetime << "\n";
    }
    cout << "Least active zombies:\n";
    LeastActiveComp least_comp;
    partial_sort(ordered_zombs.begin(), ordered_zombs.begin() + active_stats, ordered_zombs.end(), least_comp);
    for (auto it = ordered_zombs.begin(); it != ordered_zombs.begin() + active_stats; ++it) {
        cout << (*it)->name << " " << (*it)->lifetime << "\n";
    }
}