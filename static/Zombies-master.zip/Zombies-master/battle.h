// PROJECT IDENTIFIER : 9504853406CBAC39EE89AA3AD238AA12CA198043
#pragma once

#include <string>
#include <queue>
#include <utility>
#include <vector>
#include <algorithm>
#include <iostream>
#include "P2random.h"
#include "zombie.h"

using namespace std;

class Battle {
public:
    Battle(deque<Zombie*> *named_zombs_in, vector<Round> &data_in, unsigned int q_capacity_in, 
        size_t stats_in, unsigned int total_in, bool verb_in, bool med_in) 
        : named_zombs(named_zombs_in), round_data(data_in), q_capacity(q_capacity_in), 
        stats_num(stats_in), total_zombs(total_in), verb(verb_in), median(med_in) 
    {
        ordered_zombs.reserve(total_in);
        killed_zombs.reserve(total_in);
    }

    void delete_zombs() {
        while (!ordered_zombs.empty()) {
            delete ordered_zombs.back();
            ordered_zombs.pop_back();
        }
        if (!named_zombs->empty()) {
            for (auto it = named_zombs->begin(); it != named_zombs->end(); ++it) {
                delete* it;
            }
        }
    }

    void generate_zombs(size_t r_index);

    unsigned int get_median();

    void calc_median(unsigned int life_in);

    void combat_r1();

    void combat_all_r();

    void print_stats();

private:
    priority_queue<Zombie*, vector<Zombie*>, Compare> zombs;
    priority_queue<unsigned int, vector<unsigned int>, greater<unsigned int>> least_high_med;
    priority_queue<unsigned int, vector<unsigned int>, less<unsigned int>> greatest_low_med;
    deque<Zombie*>* named_zombs;
    vector<Zombie*> ordered_zombs;
    vector<Zombie*> killed_zombs;
    vector<Round> round_data;
    unsigned int q_capacity;
    size_t stats_num;
    unsigned int total_zombs;
    size_t r_data_check = 1;
    unsigned int round = 1;
    Zombie* last_victim = nullptr;
    bool verb;
    bool median;
    bool one_destroyed = false;
};